import { CreateGroupDto } from "./create-group.dto";

export type UpdateGroupDto = Partial<CreateGroupDto>;
