import { CreateCuratorDto } from "./create-curator.dto";

export type UpdateCuratorDto = Partial<CreateCuratorDto>;
