export interface CreateCuratorDto {
  first_name: string;
  last_name: string;
  patronymic: string;
  login: string;
  password: string;
}
