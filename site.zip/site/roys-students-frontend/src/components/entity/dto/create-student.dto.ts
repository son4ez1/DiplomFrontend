export interface CreateStudentDto {
  first_name: string;
  last_name: string;
  patronymic: string;
  group_id: string;
}
