export interface LoginDto {
  login: string;
  password: string;
}
