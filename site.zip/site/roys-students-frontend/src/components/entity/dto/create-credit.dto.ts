export interface CreateCreditDto {
  group_id: string;
  specialty: string;
  semester: number;
  course: number;
  discipline: string;
  curator_id: string;
  holding_date: Date;
}
