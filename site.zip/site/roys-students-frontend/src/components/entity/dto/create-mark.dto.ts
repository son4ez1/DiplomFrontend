export interface CreateMarkDto {
  mark: string;
  examId: string;
  studentId: string;
}
