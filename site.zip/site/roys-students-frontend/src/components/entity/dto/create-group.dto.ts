export interface CreateGroupDto {
  name: string;
  curator_id: string;
}
