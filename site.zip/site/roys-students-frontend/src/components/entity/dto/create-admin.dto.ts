export interface CreateAdminDto {
  key: string;
  login: string;
  password: string;
}
