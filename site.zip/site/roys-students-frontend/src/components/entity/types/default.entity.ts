export interface DefaultEntity {
  id: string;
  role: string;
  login: string;
  created_at: string;
  updated_at: string;
}
