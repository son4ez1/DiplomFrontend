export enum Role {
  ADMIN = 'admin',
  CURATOR = 'curator',
  STUDENT = 'student',
}
