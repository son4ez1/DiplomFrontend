export enum Gender {
  MALE = 'муж.',
  FEMALE = 'жен.',
}
