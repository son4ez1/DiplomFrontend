export enum ExamEnum {
  Exam = 'Exam',
  Credit = 'Credit',
}
